"use client"

import { FileText, BookOpen, Search, BarChart3 } from "lucide-react"
import { useLanguage } from "@/context/language-context"
import { Card, CardContent } from "@/components/ui/card"

const services = [
  {
    icon: FileText,
    titleKey: "services.thesis.title",
    descKey: "services.thesis.description",
  },
  {
    icon: BookOpen,
    titleKey: "services.research.title",
    descKey: "services.research.description",
  },
  {
    icon: Search,
    titleKey: "services.literature.title",
    descKey: "services.literature.description",
  },
  {
    icon: BarChart3,
    titleKey: "services.data.title",
    descKey: "services.data.description",
  },
]

export function ServicesSection() {
  const { t, language } = useLanguage()

  return (
    <section className="py-20 md:py-28 bg-background">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 text-balance">
            {t("services.title")}
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-balance">
            {t("services.subtitle")}
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => (
            <Card
              key={service.titleKey}
              className="group relative overflow-hidden border-border bg-card hover:shadow-xl transition-all duration-300 hover:-translate-y-2"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              {/* Hover Gradient Overlay */}
              <div className="absolute inset-0 bg-primary/0 group-hover:bg-primary/5 transition-colors duration-300" />
              
              <CardContent className="p-6 relative z-10">
                {/* Icon */}
                <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-5 group-hover:bg-primary group-hover:scale-110 transition-all duration-300">
                  <service.icon className="w-7 h-7 text-primary group-hover:text-primary-foreground transition-colors duration-300" />
                </div>

                {/* Content */}
                <h3 className="text-xl font-semibold text-foreground mb-3 group-hover:text-primary transition-colors duration-300">
                  {t(service.titleKey)}
                </h3>
                <p className="text-muted-foreground leading-relaxed text-sm">
                  {t(service.descKey)}
                </p>

                {/* Bottom Accent Line */}
                <div className="absolute bottom-0 left-0 right-0 h-1 bg-primary scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left rtl:origin-right" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
