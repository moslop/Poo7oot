"use client"

import Link from "next/link"
import { ArrowRight, ArrowLeft, GraduationCap, BookOpen, Award } from "lucide-react"
import { useLanguage } from "@/context/language-context"
import { Button } from "@/components/ui/button"

export function HeroSection() {
  const { t, language, dir } = useLanguage()
  const ArrowIcon = language === "ar" ? ArrowLeft : ArrowRight

  return (
    <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden bg-primary">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-20 left-10 w-72 h-72 bg-primary-foreground rounded-full blur-3xl" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-primary-foreground rounded-full blur-3xl" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-primary-foreground rounded-full blur-3xl opacity-20" />
      </div>

      {/* Grid Pattern Overlay */}
      <div 
        className="absolute inset-0 opacity-5"
        style={{
          backgroundImage: `linear-gradient(rgba(255,255,255,.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.1) 1px, transparent 1px)`,
          backgroundSize: '50px 50px'
        }}
      />

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary-foreground/10 border border-primary-foreground/20 mb-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
            <GraduationCap className="w-4 h-4 text-primary-foreground" />
            <span className="text-sm text-primary-foreground/90 font-medium">
              {language === "ar" ? "خدمات أكاديمية احترافية" : "Professional Academic Services"}
            </span>
          </div>

          {/* Main Title */}
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-primary-foreground mb-6 leading-tight text-balance animate-in fade-in slide-in-from-bottom-4 duration-700 delay-100">
            {t("hero.title")}
          </h1>

          {/* Subtitle */}
          <p className="text-xl md:text-2xl text-primary-foreground/80 font-medium mb-4 animate-in fade-in slide-in-from-bottom-4 duration-700 delay-200">
            {t("hero.subtitle")}
          </p>

          {/* Description */}
          <p className="text-lg text-primary-foreground/70 max-w-2xl mx-auto mb-10 leading-relaxed text-balance animate-in fade-in slide-in-from-bottom-4 duration-700 delay-300">
            {t("hero.description")}
          </p>

          {/* CTA Button */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-in fade-in slide-in-from-bottom-4 duration-700 delay-400">
            <Button
              asChild
              size="lg"
              className="bg-primary-foreground text-primary hover:bg-primary-foreground/90 px-8 py-6 text-lg font-semibold rounded-full group transition-all hover:scale-105"
            >
              <Link href="/order" className="flex items-center gap-2">
                {t("hero.cta")}
                <ArrowIcon className="w-5 h-5 transition-transform group-hover:translate-x-1 rtl:group-hover:-translate-x-1" />
              </Link>
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-8 max-w-lg mx-auto mt-16 animate-in fade-in slide-in-from-bottom-4 duration-700 delay-500">
            <div className="text-center">
              <div className="flex items-center justify-center w-12 h-12 mx-auto mb-3 rounded-full bg-primary-foreground/10">
                <BookOpen className="w-6 h-6 text-primary-foreground" />
              </div>
              <p className="text-3xl font-bold text-primary-foreground mb-1">500+</p>
              <p className="text-sm text-primary-foreground/70">
                {language === "ar" ? "مشروع مكتمل" : "Projects Done"}
              </p>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center w-12 h-12 mx-auto mb-3 rounded-full bg-primary-foreground/10">
                <GraduationCap className="w-6 h-6 text-primary-foreground" />
              </div>
              <p className="text-3xl font-bold text-primary-foreground mb-1">50+</p>
              <p className="text-sm text-primary-foreground/70">
                {language === "ar" ? "خبير أكاديمي" : "Expert Writers"}
              </p>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center w-12 h-12 mx-auto mb-3 rounded-full bg-primary-foreground/10">
                <Award className="w-6 h-6 text-primary-foreground" />
              </div>
              <p className="text-3xl font-bold text-primary-foreground mb-1">98%</p>
              <p className="text-sm text-primary-foreground/70">
                {language === "ar" ? "رضا العملاء" : "Satisfaction"}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Wave */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1440 120" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-auto">
          <path d="M0 120L60 110C120 100 240 80 360 70C480 60 600 60 720 65C840 70 960 80 1080 85C1200 90 1320 90 1380 90L1440 90V120H1380C1320 120 1200 120 1080 120C960 120 840 120 720 120C600 120 480 120 360 120C240 120 120 120 60 120H0Z" fill="var(--background)" />
        </svg>
      </div>
    </section>
  )
}
