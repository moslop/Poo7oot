"use client"

import Link from "next/link"
import { useLanguage } from "@/context/language-context"

export function Footer() {
  const { t, language } = useLanguage()
  const currentYear = new Date().getFullYear()

  return (
    <footer className="bg-primary text-primary-foreground py-8">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary-foreground/20 flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-sm">RA</span>
            </div>
            <span className="font-semibold">
              {language === "ar" ? "مساعد البحث" : "Research Aid"}
            </span>
          </div>
          
          <div className="flex items-center gap-6 text-sm text-primary-foreground/80">
            <Link href="/" className="hover:text-primary-foreground transition-colors">
              {t("nav.home")}
            </Link>
            <Link href="/order" className="hover:text-primary-foreground transition-colors">
              {t("nav.order")}
            </Link>
          </div>
          
          <p className="text-sm text-primary-foreground/70">
            © {currentYear} {language === "ar" ? "مساعد البحث" : "Research Aid"}. {t("footer.rights")}.
          </p>
        </div>
      </div>
    </footer>
  )
}
